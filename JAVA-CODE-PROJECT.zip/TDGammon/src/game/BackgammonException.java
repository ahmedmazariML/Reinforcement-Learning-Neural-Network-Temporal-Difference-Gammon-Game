package game;


public abstract class BackgammonException extends RuntimeException {
  protected BackgammonException(String s) {
    super(s);
  }
}